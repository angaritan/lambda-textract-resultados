# lambda-textract-resultados
Procesamiento asyncrono de archivos pdf para formatear a texto con base en AWS
